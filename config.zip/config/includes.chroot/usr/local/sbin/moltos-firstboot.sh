#!/bin/bash
WALL='file:///usr/share/backgrounds/moltos/moltos-wallpaper.png'
ICON='/usr/share/icons/hicolor/512x512/apps/moltos.png'
sleep 5

for u in user debian debian-live moltos; do
  if id "$u" &>/dev/null; then
    su -l "$u" -c "gsettings set org.gnome.desktop.background picture-uri \"$WALL\"" || true
    su -l "$u" -c "gsettings set org.gnome.desktop.screensaver picture-uri \"$WALL\"" || true
    su -l "$u" -c "gsettings set org.gnome.shell.extensions.dash-to-dock dock-position 'BOTTOM'" || true
    su -l "$u" -c "gsettings set org.gnome.shell.extensions.dash-to-dock autohide false" || true
    su -l "$u" -c "gsettings set org.gnome.shell.extensions.dash-to-dock dash-max-icon-size 48" || true
    ICON_PATH="/var/lib/AccountsService/icons/${u}.png"
    cp "$ICON" "$ICON_PATH" 2>/dev/null || true
    mkdir -p /var/lib/AccountsService/users
    cat > /var/lib/AccountsService/users/${u} <<ACC
[User]
Icon=${ICON_PATH}
Language=en_US.UTF-8
SystemAccount=false
XSession=gnome
RealName=MoltOS User
ACC
  fi
done

dconf update || true
